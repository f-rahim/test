import React from 'react';

const Test_function = (props) => {
    return (
        <div>
            <h3>{props.friend} is my best friend.</h3>
        </div>
    )
}

export default Test_function;